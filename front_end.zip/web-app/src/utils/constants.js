export const constants = {
 
  // serverUrl: 'http://localhost:4000',
  // serverUrl: 'http://localhost:7000',
  serverUrl: 'http://localhost:9999',

}
