import { useState } from "react";

    
    
    
    function B(){

        const [items,SetItems]=useState(["sun","mon"]);

        const add=()=>{
            const newItem = "tues";
            SetItems([...items,newItem]);
        }

        return<>
            <br/>
            Search
            <input type="search"></input>    
            <br/>
            <form>
                New Item: <input type="text"></input>
                <button onClick={add}>Add</button>
            </form>
            <div>
                List:
                <ul>
          {items.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul/*
            </div>
        </>
    }
    export default B;