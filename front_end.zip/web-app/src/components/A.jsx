// import axios from "axios";
import { useState,useEffect } from "react";

function A(){

    // return and UseState

    // const [myData,setMyData]=useState([]);
    const [count,setCount]=useState(0);

    // const getAxiosData=async()=>{
    //     const res= await axios.get("https://jsonplaceholder.typicode.com/posts");
    //     setMyData(res.data);
    // }

    // const getAxiosData = ()=>{
    //     axios
    //         .get("https://jsonplaceholder.typicode.com/posts")
    //         .then((res)=>{setMyData(res.data)})
    // }

    // useEffect(()=>{
    //     getAxiosData();
    // })

    const increament=()=>{
        setCount(prevCount => prevCount+1);
        setCount(prevC=>prevC+1);
    }
    const decreament=()=>{
        setCount(prevC => prevC-1);
    }

    return(
        <>
        <h2>TUITORIAL</h2>
        {/* <div>
            {myData.slice(0,10).map((post)=>{
                const{id,title,body}=post
                return (
                    <div className='col-md-3'> 
                        <div className="card">
                            <div className="card-body">
                                card-body
                                <div className="card-text">card text </div>
                            </div>
                        </div>
                    </div>
                )
            })}
        </div> */}
       
        <h2>Return and UseState</h2>
        <button onClick={decreament}>-</button>
        <div>{count}</div>
        <button onClick={increament}>+</button>

        {/* <div>
            {myData.slice(0,12).map((post)=>{
            const {id,title,body} =post
            return (<div className='card-md-3'  id="id" style={{padding : '2em', border : '1px solid #888'}}>
                        <h2>{title.slice(0,15).toUpperCase()}</h2>
                        <p>{body.slice(0.100)}</p>
                    </div>)
        })
        }   
        </div> */}
        
        
    </>
    )
}
export default A;   