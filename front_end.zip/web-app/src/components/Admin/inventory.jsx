import { useEffect , useState } from "react"
import { toast } from "react-toastify"
import { useNavigate } from 'react-router-dom'
import { getInventoryProduct } from "../../services/product"



function Inventory() {
    const [inventory, setIventory] = useState([])

        const navigate = useNavigate()
        useEffect(() => {
          // get the list of vendors from server
          loadInventory()
        }, [])

    
        const loadInventory = async () => {
                  const response = await getInventoryProduct()
                //   if (response['status'] === 'success') {
                    console.log(response)
                    if(response){
                        setIventory(response['data'])
                    debugger;
                  } else {
                    toast.error('Error while calling get /products api')
                  }
                }


    return (  
                <div>
                    
                <h1 style={{ textAlign: 'center', margin: 10 }}>Inventory</h1>
                <div className='row' style={{ marginTop: 50 }}>
                    <div className="container">
                    <table className="table table-striped table-bordered table-hover table-responsive">
                                <tr>
                                    <th>
                                         productId
                                    </th>
                                    <th>
                                    vendorProductId
                                    </th>
                                    <th>
                                    productName 
                                    </th>
                                    <th>
                                    productMfgDate
                                    </th>
                                    <th>
                                    productExpDate
                                    </th>
                                    <th>
                                    pq
                                    </th>
                                    <th>productPrice</th>
                                </tr>
                                <tbody>
                                {inventory.map((prod) => {
                                     return (
                                        <tr>
                                        <td>
                                            {prod['productId']}
                                        </td>
                                        <td>
                                            {prod['vendorProductId']}
                                        </td>
                                        <td>
                                            {prod['productName']}
                                        </td>
                                        <td>
                                            {prod['productMfgDate']}
                                        </td>
                                        <td>
                                            {prod['productExpDate']}
                                        </td>
                                        <td>
                                            {prod['pq']}
                                        </td>
                                        <td>
                                            {prod['productPrice']}
                                        </td>
                                    </tr>
                                             )
                  })}
        
                                </tbody>
                            </table>
                    </div>
                  
                </div>
              </div>
            );
}

export default Inventory;