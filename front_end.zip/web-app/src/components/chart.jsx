import React, { useEffect, useState } from 'react';
import CanvasJSReact from '../lib/canvasjs.react'
import { getPurchasedProductsByCustomer } from '../services/product';

const CanvasJSChart = CanvasJSReact.CanvasJSChart;

function ChartComponent() {

  const [products, setProducts] = useState([]);

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await getPurchasedProductsByCustomer();
        if (response) {
          setProducts(response['data']);
        } else {
          console.log("Error while calling get /product api");
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    }

    fetchData();
  }, []);

  const chartOptions = {
    theme: 'light2',
    title: {
      text: 'Sold Products',
    },
    data: [
      {
        type: 'column',
        dataPoints: products.map(product => ({
          label: product.productName,
          y: product.quantity,
        })),
      },
    ],
  };

  return (
    <div>
      {products.length > 0 ? (
        <CanvasJSChart options={chartOptions} />
      ) : (
        <p>Loading chart...</p>
      )}
    </div>
  );
}

export default ChartComponent;