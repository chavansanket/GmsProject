// import NavigationBar from "./navigationBar"
// import { useEffect, useState } from "react";
// import { getAddress, getProfileDetails, updateAddress, updateProfile } from "../services/customer";
// import { log } from "../utils/utils";
// import { toast } from "react-toastify";
// import EditNoteIcon from '@mui/icons-material/EditNote';
// import EditLocationAltIcon from '@mui/icons-material/EditLocationAlt';

// import { Button, Modal, Form } from 'react-bootstrap';
// import { cartQty } from "../services/cart";
// import Footer from "./footer";
// function Profile() {
    
//     const [profile, setProfile] = useState([]);
//     const [address,setAddress ] = useState([]);
//     const [firstName, setFirstName] = useState('');
//     const [lastName, setLastName] = useState('');
//     const [email, setEmail] = useState('');
//     const [phone, setPhone] = useState('');
//     const [adrLine1, setAdrLine1] = useState('');
//     const [adrLine2, setAdrLine2] = useState('');
//     const [city, setCity] = useState('');
//     const [state, setState] = useState('');
//     const [country, setCountry] = useState('');
//     const [zipcode, setZipcode] = useState('');
//     const [password, setPassword] = useState('');


//     const [count, setCount] = useState();




//     // {address.adrLine1}  ,  {address.adrLine2} 
//     // {address.city}  {address.country} {address.zipCode}
    
//     const [showProfile, setProfileShow] = useState(false);
//     const handleProfileClose = () => setProfileShow(false);
//     const handleProfileShow = () => setProfileShow(true);
    
//     const [showAddress, setAddressShow] = useState(false);
//     const handleAddressClose = () => setAddressShow(false);
//     const handleAddressShow = () => setAddressShow(true);

//     const handleProfileSubmit = (e) => {
//       e.preventDefault();
//       // Process the form data (name and email) here
//       log("in profile edit---")
//       // console.log('Email:', email);
//       // // Close the modal
//       uProfile()
//       handleProfileClose();
      
//     };

//     const handleAddressSubmit = (e) => {
//       e.preventDefault();
//       // Process the form data (name and email) here
//       log("in address edit---")
//       // console.log('Email:', email);
//       // // Close the modal
//       handleAddressShow();
//       uAddress()


//     };


//     const uProfile = async() => {
//       if(password!=='' && firstName!=='' && lastName!==''){
//         const response = await updateProfile(sessionStorage.getItem('customerId'),firstName,lastName,email,password,phone);
//         loadProfile()
//         log(response.data)
//         toast.dark(" Profile updated",{
//           style:{
//             top: '80px'
//           }
//         })
//       }
//       }

//       const uAddress = async() => {
//         const response = await updateAddress(adrLine1,adrLine2,city,state,country,zipcode,sessionStorage.getItem('customerId'),);  
//         loadAddress()
//         log(response.data)
//         toast.dark(" Address updated",{
//           style:{
//             top: '80px'
//           }
//           })
//         }
    




    
//   useEffect(() => {
//     loadProfile();
//     loadAddress();
//     loadQty(sessionStorage.getItem('customerId'))
//   }, []);


//   const loadQty = async (customerId) => {
//     const response = await cartQty(customerId)
//     if (response['status'] === 200) {
//       setCount(response.data)
//     log(count) 
//     } else {
//       toast.error('Error while calling get /qty api')
//     }
//   }

//   const loadProfile = async () => {
//     const response = await getProfileDetails(sessionStorage.getItem('customerId'));
//     if (response['status'] === 200) {
//       setProfile(response.data);
//       log(response.data);
//       setFirstName(profile.firstName)
//       setLastName(profile.lastName)
//       setPhone(profile.phone)
//       setEmail(profile.email)
//       setPassword(profile.password)

//     } else {
//       toast.error('Error while calling get /profile api');
//     }
//   };

//   const loadAddress = async () => {
//     const response = await getAddress(sessionStorage.getItem('customerId'));
//     if (response['status'] === 200) {
//       setAddress(response.data);
//       setAdrLine1(address.adrLine1)
//       setAdrLine2(address.adrLine2)
//       setCity(address.city)
//       setState(address.state)
//       setCountry(address.country)
//       setZipcode(address.zipCode)
//       log(response.data);
//     } else {
//       toast.error('Error while calling get /Address api');
//     }
//   };

//     return (
      
//       <div    style={{background: 'radial-gradient(at center, #87CEEB, #FFFFFF)'
//         ,marginTop:60} }>
//       <NavigationBar counts={count}></NavigationBar>
        
//   <div className="container py-5">
   

//     <div className="row" style={{display:"flex"}}>
//       <div className="col-lg-4"></div>
//       <div className="col-lg-4" style={{marginTop:10}}>
//         {/* <div className="card mb-4" style={{justifyContent:"center"}}> */}
//           <div className=" text-center">
//             <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava3.webp" alt="avatar" className="rounded-circle img-fluid" style={{width: 170}}/>
//             <h4 className="my-3 " style={{fontFamily:"cursive"}}>{profile.firstName}</h4>
           
           
//           {/* </div> */}
//         </div>
//       </div>


//       <div style={{display:"flex"}}>
//       <div className="col-lg-5" style={{marginRight:100}}>
//         <div className="card mb-4">
//           <div className="card-body">
//             <div className="row">
//               <div className="col-sm-3">
//                 <p className="mb-0">Full Name</p>
//               </div>
//               <div className="col-sm-9">
//                 <p className="text-muted mb-0">{profile.firstName}  {profile.lastName}</p>
//               </div>
//             </div>
//             <hr/>
//             <div className="row">
//               <div className="col-sm-3">
//                 <p className="mb-0">Email</p>
//               </div>
//               <div className="col-sm-9">
//                 <p className="text-muted mb-0">{profile.email}</p>
//               </div>
//             </div>
//             <hr/>
//             <div className="row">
//               <div className="col-sm-3">
//                 <p className="mb-0">Mobile</p>
//               </div>
//               <div className="col-sm-9">
//                 <p className="text-muted mb-0">{profile.phone}</p>
//               </div>
//             </div>
//             <hr/>
//             <div className="row">
//               <div className="col-sm-4">
//               </div>
//               <div className="col-sm-1">
//               </div>
//               <div className="col-sm-1">
        
//               <button onClick={handleProfileShow} style={{ border: 'none', background: 'transparent', cursor: 'pointer', padding: 0 }}>
//         <EditNoteIcon fontSize="large" />
//       </button>
//               </div>
//               <div className="col-sm-4">
//               </div>
//             </div>
            
//           </div>
//         </div>

     
//       </div>
//       <div className="col-lg-5">
//         <div className="card mb-4">
//           <div className="card-body">
//             <div className="row">
//               <div className="col-sm-3">
//                 <p className="mb-0">Street</p>
//               </div>
//               <div className="col-sm-9">
//                 <p className="text-muted mb-0">{address.adrLine1}  ,  {address.adrLine2}</p>
//               </div>
//             </div>
//             <hr/>
//             <div className="row">
//               <div className="col-sm-3">
//                 <p className="mb-0">City</p>
//               </div>
//               <div className="col-sm-9">
//                 <p className="text-muted mb-0">{address.city}</p>
//               </div>
//             </div>
//             <hr/>
//             <div className="row">
//               <div className="col-sm-3">
//                 <p className="mb-0">Country</p>
//               </div>
//               <div className="col-sm-9">
//                 <p className="text-muted mb-0">{address.country}</p>
//               </div>
//             </div>
//             <hr/>
//             <div className="row">
//               <div className="col-sm-3">
//                 <p className="mb-0">Zip code</p>
//               </div>
//               <div className="col-sm-9">
//                 <p className="text-muted mb-0">{address.zipCode}</p>
//               </div>
//             </div>
//             <hr/>
//             <div className="row">
//               <div className="col-sm-4">
//               </div>
//               <div className="col-sm-1">
//               </div>
//               <div className="col-sm-1">
//               <button onClick={handleAddressShow} style={{ border: 'none', background: 'transparent', cursor: 'pointer', padding: 0 }}>
//         <EditLocationAltIcon fontSize="large" />
//       </button>
//               </div>
//               <div className="col-sm-4">
//               </div>
//             </div>
//             {/* <div className="row">
//               <div className="col-sm-3">
//                 <p className="mb-0">Address</p>
//               </div>
//               <div className="col-sm-9">
//                 <p className="text-muted mb-0">Bay Area, San Francisco, CA</p>
//               </div>
//             </div> */}
//           </div>
//         </div>
        
//       </div>
//       </div>
//     </div>
//   </div>
// {/* </section> */}





// <Modal show={showAddress} onHide={handleAddressClose}>
//         <Modal.Header closeButton>
//           <Modal.Title>Edit Address</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>

// {/*         
//         {address.adrLine1}  ,  {address.adrLine2} 
//         {address.city}  {address.country} {address.zipCode}
//         */}          
//           <Form onSubmit={handleAddressSubmit}>
//             <Form.Group controlId="inputName">
//               <Form.Label>Address Line 1</Form.Label>
//               <Form.Control
//                 type="text"
//                 placeholder="Enter your Address line 1"
//                 value={adrLine1}
//                 onChange={(e) => setAdrLine1(e.target.value)}
//               />
//             </Form.Group>
//             <Form.Group controlId="inputName">
//               <Form.Label>Address Line 2</Form.Label>
//               <Form.Control
//                 type="text"
//                 placeholder="Enter Address Line 2"
//                 value={adrLine2}
//                 onChange={(e) => setAdrLine2(e.target.value)}
//               />

              
//             </Form.Group>
//             <Form.Group controlId="inputEmail">
//               <Form.Label>City</Form.Label>
//               <Form.Control
//                 type="text"
//                 placeholder="Enter your city"
//                 value={city}
//                 onChange={(e) => setCity(e.target.value)}
//               />
//             </Form.Group>

          

//             <Form.Group controlId="state">
//               <Form.Label>State</Form.Label>
//               <Form.Control
//                 type="text"
//                 placeholder="Enter your state"
//                 value={state}
//                 onChange={(e) => setState(e.target.value)}
//               />
//             </Form.Group>

//             <Form.Group controlId="countrycd  ">
//               <Form.Label>Country</Form.Label>
//               <Form.Control
//                 type="text"
//                 placeholder="Enter your country"
//                 value={country}
//                 onChange={(e) => setCountry(e.target.value)}
//               />
//             </Form.Group>

//             <Form.Group controlId="zipcode">
//               <Form.Label>Zip-Code</Form.Label>
//               <Form.Control
//                 type="text"
//                 placeholder="Enter your Zip-Code"
//                 value={zipcode  }
//                 onChange={(e) => setZipcode(e.target.value)}
//               />
//             </Form.Group>
//             <Button variant="primary" type="submit">
//               Submit
//             </Button>
//           </Form>
//           </Modal.Body>
//         <Modal.Footer>
//           <Button variant="secondary" onClick={handleAddressClose}>
//             Close
//           </Button>
//         </Modal.Footer>
//       </Modal>




//       <Modal show={showProfile} onHide={handleProfileClose}>
//         <Modal.Header closeButton>
//           <Modal.Title>Edit profile</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
          
//           <Form onSubmit={handleProfileSubmit}>
//             <Form.Group controlId="inputName">
//               <Form.Label>First name</Form.Label>
//               <Form.Control
//                 type="text"
//                 placeholder="Enter your first name"
//                 value={firstName}
//                 onChange={(e) => setFirstName(e.target.value)}
//               />
//             </Form.Group>
//             <Form.Group controlId="inputName">
//               <Form.Label>Last Name</Form.Label>
//               <Form.Control
//                 type="text"
//                 placeholder="Enter your Last name"
//                 value={lastName}
//                 onChange={(e) => setLastName(e.target.value)}
//               />
//             </Form.Group>
//             <Form.Group controlId="inputEmail">
//               <Form.Label>Email</Form.Label>
//               <Form.Control
//                 type="email"
//                 placeholder="Enter your email"
//                 value={email}
//                 onChange={(e) => setEmail(e.target.value)}
//               />
//             </Form.Group>

//             <Form.Group controlId="inputEmail">
//               <Form.Label>Mobile</Form.Label>
//               <Form.Control
//                 type="phone"
//                 placeholder="Enter your Mobile No."
//                 value={phone}
//                 onChange={(e) => setPhone(e.target.value)}
//               />
//             </Form.Group>

//              <Form.Group controlId="inputEmail">
//               <Form.Label>Password</Form.Label>
//               <Form.Control
//                 type="phone"
//                 placeholder="Enter new password"
//                 value={password }
//                 onChange={(e) => setPassword(e.target.value)}
//               />
//             </Form.Group>
//             <Button variant="primary" type="submit">
//               Submit
//             </Button>
//           </Form>
//         </Modal.Body>
//         <Modal.Footer>
//           <Button variant="secondary" onClick={handleProfileClose}>
//             Close
//           </Button>
//         </Modal.Footer>
//       </Modal>
//       <Footer></Footer>
//     </div>
        


//     )
//   }
  
//   export default Profile;